from rest_framework import serializers
from .models import Aboutus

class AboutusSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Aboutus
        fields = [ 'name','imagesHead','imagesSecond','title','heading','updatedDate']