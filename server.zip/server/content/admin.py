from django.contrib import admin
from .models import Content

# Register your models here.
class ContentAdmin(admin.ModelAdmin):
    list_display = ('name','imagesHead','imagesSecond','description','updatedDate','title','heading')
    
admin.site.register(Content,ContentAdmin)