from django.db import models

# Create your models here.
class Content(models.Model):
    name = models.CharField(max_length=100)
    imagesHead = models.ImageField(upload_to='content/') 
    imagesSecond = models.ImageField(upload_to='content/')
    description = models.CharField(max_length=100)
    title = models.CharField(max_length=100) 
    heading = models.CharField(max_length=100)
    updatedDate = models.DateTimeField(auto_now=True)