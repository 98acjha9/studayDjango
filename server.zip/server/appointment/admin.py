from django.contrib import admin
from .models import Appointment

# Register your models here.
class AppointmentsAdmin(admin.ModelAdmin):
    list_display = ('name','email','mobile','purpose','message','toDate','fromDate','updatedDate')
    
admin.site.register(Appointment,AppointmentsAdmin)

# Register your models here.
