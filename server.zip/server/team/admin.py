from django.contrib import admin
from .models import Team

# Register your models here.
class TeamAdmin(admin.ModelAdmin):
    list_display = ('name','imagesHead','description','updatedDate')
    
admin.site.register(Team,TeamAdmin)
# Register your models here.
