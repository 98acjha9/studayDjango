from django.contrib import admin
from .models import Review

# Register your models here.
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('name','email','rating','updatedDate')
    
admin.site.register(Review,ReviewAdmin)

# Register your models here.
