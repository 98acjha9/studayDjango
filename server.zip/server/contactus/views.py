from django.shortcuts import render
from rest_framework import permissions, viewsets
from .models import Contactus
from .serializers import ContactusSerializer

# Create your views here.
class NewsAlertViews(viewsets.ModelViewSet):
    queryset = Contactus.objects.all()
    serializer_class = ContactusSerializer
    permission_classes = [permissions.IsAuthenticated]

# Create your views here.
