from rest_framework import serializers
from .models import Contactus

class ContactusSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Contactus
        fields = [ 'name','email','subject','updatedDate','message']