from django.db import models

class NewsAlert(models.Model):
    email = models.EmailField() 
