from django.contrib import admin
from .models import NewsAlert
# Register your models here.
class NewsAlertsAdmin(admin.ModelAdmin):
    list_display = ('email',)
    
admin.site.register(NewsAlert,NewsAlertsAdmin)
