from rest_framework import serializers
from .models import NewsAlert

class NewsSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = NewsAlert
        fields = [ 'email']